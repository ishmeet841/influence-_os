
# Demo Script (10 min)
1. Problem & Goal (1 min)
2. Architecture overview (1 min)
3. Profile ingest (1 min)
4. Trend research & idea generation (2 min)
5. Scheduling & A/B (2 min)
6. Analytics summary (1 min)
7. Next steps & Q&A (2 min)
