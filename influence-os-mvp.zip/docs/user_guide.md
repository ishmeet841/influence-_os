
# User Guide
1. Go to **Profile** and fill your details. Save.
2. Go to **Generate Ideas**, enter a topic, click **Generate**.
3. Pick/compose your post in **Schedule Post**, set date/time, **Schedule**.
4. Use **Analytics** to see summary. (Use **/analytics/ingest** to record metrics after posting.)

**Live Posting:** set `LINKEDIN_USE_MOCK=false` and provide OAuth credentials in `backend/.env`.
